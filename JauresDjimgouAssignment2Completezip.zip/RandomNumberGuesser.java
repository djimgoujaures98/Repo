/*
 * Class: CMSC203 
 * Instructor: Khandan Monshi
 * Description: (Give a brief description for each Class)
 * Due: 9/28/2021
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Jaures Djimgou
*/


import java.util.Scanner; // import Scanner class
public class RandomNumberGuesser { //Driver class

        public static void main(String[] args) { // main method
          //required variables declaration     
          int randNum, nextGuess, highGuess, lowGuess;
          String resp;
          char response = 0;
                
                
           Scanner keyboard= new Scanner (System.in);  //creating Scanner object
                
           RNG rng= new RNG(); ////creating RNG class object
                
                
           do {
           lowGuess=1;
           highGuess=100;
           randNum=RNG.rand(); //generating random number by calling RNG.rand() method
           RNG.resetCount();
           System.out.println("/*\r\n"
           		+ " * Class: CMSC203 \r\n"
           		+ " * Instructor: Khandan Monshi\r\n"
           		+ " * Due: 9/28/2021\r\n"
           		+ " * Platform/compiler: Eclipse\r\n"
           		+ " * I pledge that I have completed the programming assignment independently.\r\n"
           		+ "   I have not copied the code from a student or any source.\r\n"
           		+ "   I have not given my code to any student.\r\n"
           		+ "   Programmer name: Jaures Djimgou\r\n"
           		+ "*/"); // Print header
           System.out.println("Enter your first guess"); //asking user for input the number
                
           nextGuess= keyboard.nextInt(); //taking input from user
                
                                
             do { 
                
                
             if (nextGuess>randNum) { 
                        
                    if(RNG.inputValidation(nextGuess, lowGuess, highGuess))
                {
                    if(nextGuess<=randNum && (randNum-nextGuess)<(randNum-lowGuess))
                   {
                       lowGuess=nextGuess;
                           
                   }
                   if(nextGuess>=randNum && (nextGuess-randNum)<(highGuess-randNum))
                   {
                       highGuess=nextGuess;
                   }
               }
                        
            System.out.println("Number of guesses is "+rng.getCount());     
                        
            System.out.println("Your guess is too high");
                
            highGuess=nextGuess;
                                                                
            System.out.println("Enter your next guess between "+lowGuess+" and "+highGuess);
                
            nextGuess= keyboard.nextInt();
                
            } else if (nextGuess<randNum) { 
                
                    if(RNG.inputValidation(nextGuess, lowGuess, highGuess))
               {
                   if(nextGuess<=randNum && (randNum-nextGuess)<(randNum-lowGuess))
                   {
                       lowGuess=nextGuess;
                   }
                   if(nextGuess>=randNum && (nextGuess-randNum)<(highGuess-randNum))
                   {
                       highGuess=nextGuess;
                   }
               }
                        
            System.out.println("Number of guesses is "+rng.getCount());     
                        
            System.out.println("Your guess is too low");
                        
            lowGuess=nextGuess;
                        
            System.out.println("Enter your next guess between "+lowGuess+" and "+highGuess);
                
            nextGuess= keyboard.nextInt();
            }
            }while (nextGuess!=(randNum));
                
            if(RNG.inputValidation(nextGuess, lowGuess, highGuess))
    {
        if(nextGuess<=randNum && (randNum-nextGuess)<(randNum-lowGuess))
        {
            lowGuess=nextGuess;
        }
        if(nextGuess>=randNum && (nextGuess-randNum)<(highGuess-randNum))
        {
            highGuess=nextGuess;
        }
    }
                
            System.out.println("Number of guesses is "+rng.getCount());
                
            System.out.println("Congratulations, you guessed correctly \n Try again (y or n)");     
                
            resp=keyboard.next();
                
            response=resp.charAt(0);
                
            while (response != 'Y' && response != 'y' && response != 'N' && response != 'n')
    {       System.out.print("Please enter Yes or No: ");
                    resp=keyboard.nextLine();
                    response=resp.charAt(0);}
                
            }while (response=='Y' || response=='y');
            System.out.println("Thank you for playing...");
          
            }

}