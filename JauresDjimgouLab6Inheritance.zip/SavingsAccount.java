public class SavingsAccount extends BankAccount {
private double rate;
private int savingsNumber;
private int interest;
private String accountNumber;

public SavingsAccount (double amount) {
super(amount);

this.rate = 2.5;
this.savingsNumber = 0;
this.accountNumber = this.getAccountNumber() + String.valueOf(savingsNumber);
savingsNumber++;

}

public SavingsAccount (SavingsAccount oldAccount, double amount) {
super(oldAccount, amount);
this.accountNumber = this.getAccountNumber() + String.valueOf(savingsNumber);
savingsNumber++;
this.rate = 2.5;
}

public SavingsAccount(String string, int i) {
	// TODO Auto-generated constructor stub
}

public String getAccountNumber() {
return accountNumber;
}

@Override
public String toString() {
return "SavingsAccount [rate=" + rate + ", savingsNumber=" + savingsNumber + ", accountNumber=" + accountNumber + "]";
}

public void postInterest() {
	// TODO Auto-generated method stub
	
}
}