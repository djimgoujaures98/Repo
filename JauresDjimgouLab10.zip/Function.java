
public abstract class Function {

}
