
public class GraphPanelFX {

}
