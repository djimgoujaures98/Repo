
public interface GraphManagerInterface {

}
